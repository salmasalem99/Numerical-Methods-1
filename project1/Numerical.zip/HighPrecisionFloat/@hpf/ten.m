function mat10 = ten(varargin)
% hpf.ten - the hpf scalar 10
%
% hpf.ten(D) - scalar HPF number 10, with D digits

mat10 = hpf('10',varargin{:});








