function [A,jb] = rref(A,tol)
%RREF   Reduced row echelon form.
%   R = RREF(A) produces the reduced row echelon form of A.
%       Rational output disabled for HPF input.
%
%   [R,jb] = RREF(A) also returns a vector, jb, so that:
%       r = length(jb) is this algorithm's idea of the rank of A,
%       x(jb) are the bound variables in a linear system, Ax = b,
%       A(:,jb) is a basis for the range of A,
%       R(1:r,jb) is the r-by-r identity matrix.
%
%   [R,jb] = RREF(A,TOL) uses the given tolerance in the rank tests.
%
%   Roundoff errors may cause this algorithm to compute a different
%   value for the rank than RANK, ORTH and NULL.
%
%   Class support for input A:
%      float: double, single, HPF
%
%   See also RANK, ORTH, NULL, QR, SVD.

%   Copyright 1984-2005 The MathWorks, Inc. 
%   Modified to work on HPF by JRD, 2017

[m,n] = size(A);

if ~isa(A,'hpf')
  % then tol must have been hpf, and A is a double.
  % So make A an hpf array, with the same number of digits as tol
  A = hpf(A,tol.NumberOfDigits);
end

% Compute the default tolerance if none was provided.
if (nargin < 2) || isempty(tol)
  infnormA = max(sum(abs(A),2));
  tol = max(m,n)*infnormA*eps(A(1));
elseif ~isa(tol,'hpf')
  % A was hpf to get in here, but tol was not, so convert tol to hpf
  tol = hpf(tol,A(1).NumberOfDigits);
end

% Loop over the entire matrix.
i = 1;
j = 1;
jb = [];
while (i <= m) && (j <= n)
   % Find value and index of largest element in the remainder of column j.
   [p,k] = max(abs(A(i:m,j))); k = k+i-1;
   if (p <= tol)
      % The column is negligible, zero it out.
      A(i:m,j) = zeros(m-i+1,1);
      j = j + 1;
   else
      % Remember column index
      jb = [jb j];
      % Swap i-th and k-th rows.
      A([i k],j:n) = A([k i],j:n);
      % Divide the pivot row by the pivot element.
      A(i,j:n) = A(i,j:n)/A(i,j);
      % Subtract multiples of the pivot row from all the other rows.
      for k = [1:i-1 i+1:m]
         A(k,j:n) = A(k,j:n) - A(k,j)*A(i,j:n);
      end
      i = i + 1;
      j = j + 1;
   end
end


